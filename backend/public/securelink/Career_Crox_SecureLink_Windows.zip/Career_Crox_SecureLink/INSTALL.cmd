@echo off
setlocal
set "CC_SECURELINK_SOURCE=%~dp0Career Crox SecureLink.exe"
set "CC_SECURELINK_INSTALL=%LOCALAPPDATA%\Career Crox\SecureLink"
echo Career Crox SecureLink - Windows x64
if not exist "%CC_SECURELINK_SOURCE%" (echo Extract the complete ZIP first. & pause & exit /b 1)
powershell.exe -NoLogo -NoProfile -NonInteractive -Command "$ErrorActionPreference='Stop'; $h=(Get-FileHash -LiteralPath $env:CC_SECURELINK_SOURCE -Algorithm SHA256).Hash; if($h -ne 'FF3AD078212A0393EF6E83BF486AD3116A7A23E4826B2A57A2141351EC537EE9'){throw 'File checksum mismatch. Do not install this copy.'}; if(-not [Environment]::Is64BitOperatingSystem){throw 'Windows x64 is required.'}"
if errorlevel 1 (echo Installation stopped. No files installed. & pause & exit /b 1)
if not exist "%CC_SECURELINK_INSTALL%" mkdir "%CC_SECURELINK_INSTALL%"
copy /Y "%CC_SECURELINK_SOURCE%" "%CC_SECURELINK_INSTALL%\Career Crox SecureLink.exe" >nul
if errorlevel 1 (echo Could not copy the app. Close the running app and try again. & pause & exit /b 1)
powershell.exe -NoLogo -NoProfile -NonInteractive -Command "$ErrorActionPreference='Stop'; $s=(New-Object -ComObject WScript.Shell).CreateShortcut([IO.Path]::Combine([Environment]::GetFolderPath('Programs'),'Career Crox SecureLink.lnk')); $s.TargetPath=[IO.Path]::Combine($env:CC_SECURELINK_INSTALL,'Career Crox SecureLink.exe'); $s.WorkingDirectory=$env:CC_SECURELINK_INSTALL; $s.Description='Career Crox SecureLink - visible, consent-based remote assistance'; $s.Save()"
if errorlevel 1 (echo App copied. Could not create Start menu shortcut. & pause & exit /b 1)
echo Installed. Open Career Crox SecureLink from the Windows Start menu.
echo Screen sharing and remote control still require the employee's permission.
echo No service, startup task or security setting was changed.
pause
