@echo off
setlocal
set "CC_SECURELINK_INSTALL=%LOCALAPPDATA%\Career Crox\SecureLink"
echo Close Career Crox SecureLink before uninstalling.
pause
if exist "%CC_SECURELINK_INSTALL%\Career Crox SecureLink.exe" del "%CC_SECURELINK_INSTALL%\Career Crox SecureLink.exe"
powershell.exe -NoLogo -NoProfile -NonInteractive -Command "$p=[IO.Path]::Combine([Environment]::GetFolderPath('Programs'),'Career Crox SecureLink.lnk'); if(Test-Path -LiteralPath $p){Remove-Item -LiteralPath $p}"
if exist "%CC_SECURELINK_INSTALL%" rmdir "%CC_SECURELINK_INSTALL%" 2>nul
echo Uninstall finished. Your CRM data was not changed.
pause
